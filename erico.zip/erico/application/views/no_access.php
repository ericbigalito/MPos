<?php
echo lang('error_no_permission_module').' '.$module_name; 
?> 