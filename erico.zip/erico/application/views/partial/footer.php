<div id="footer" class="col-md-12 hidden-print">
	<?php echo lang('common_please_visit_my'); ?> 
		<a href="Trace POS" target="_blank">
			<?php //echo lang('common_website'); ?>
		</a> 
	<?php echo lang('common_learn_about_project'); ?>.
		<span class="text-info"><?php echo lang('common_you_are_using_phppos')?> <span class="label label-info"> <?php echo APPLICATION_VERSION; ?></span></span>
</div>

</div><!--end #content-->
</div><!--end #wrapper-->
</body>
</html>