<!DOCTYPE html>
<html>
	<head>
		<title><?php echo lang('login_reset_password'); ?></title>
	</head>
	<body>
		<?php echo lang('login_password_has_been_reset'); ?><br />
		<?php echo anchor('login', lang('login_login')); ?>
	</body>
</html>